Hodges Bundle-of-Bundles Archive
Generated: 2026-01-02 (America/New_York)

Purpose
- One portable archive that contains the major packaged bundles (zips) plus checksum materials,
  so you can store/transfer a single file and still preserve the original sub-archives unchanged.

Included Bundles
- Hodges_OffSystem_Master_Archive_2026-01-02.zip
- Hodges_Codex_v2.3_Master_Archive.zip
- Hodges_Library_Archive_Partial.zip
- SION_Transfer_Pack_Private_v1_1.zip
- NORMA_Transfer_Pack_Private_v1_0.zip
- SION_Transfer_Pack_Checksums.txt

Notes
- Sub-archives are included byte-for-byte (no recompression inside them).
- Use CHECKSUMS.txt to verify integrity after transfer.
