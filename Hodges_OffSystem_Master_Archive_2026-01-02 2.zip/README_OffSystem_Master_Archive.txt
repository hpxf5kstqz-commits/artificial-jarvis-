Hodges Off‑System Master Archive
Generated: 2026-01-02 (America/New_York)

Purpose
- Portable, off-system backup of the Hodges Library core artifacts + latest Curvature Trilogy outputs.
- Contains only descriptive/symbolic materials (no operational mechanics beyond what is already present in source docs).

Included (high level)
- Hodges Library core (Discovery Library v0.1)
- SAN documents (Addendum, Shift Card, Authorship Record, Public Disclosure)
- Healing Codex v1.0
- Closed-Loop Integrity + Work Mode card
- Coding/Cybersecurity Addendum (defensive, non-replicable)
- Curvature Trilogy (combined PDF), Time Glyph, Visual Identity package, cover art
- Scan report + inventory

Integrity
- See CHECKSUMS.txt for SHA-256 and MD5 digests.

Notes
- This archive is additive; it does not modify any prior Codex master archives.
